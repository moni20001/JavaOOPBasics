package Pizza;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] pizzaTokens = scan.nextLine().split("\\s+");
        boolean passedAllTest = true;
        Pizza pizza = null;
        try{
            pizza = new Pizza(pizzaTokens[1],Integer.parseInt(pizzaTokens[2]));
            try{
                String[] doughTokens = scan.nextLine().split("\\s+");
                Dough dough = new Dough(doughTokens[1],doughTokens[2],Integer.parseInt(doughTokens[3]));
                pizza.addDough(dough);
                for (int i = 0; i < pizza.getNumberOfTopics(); i++) {
                    String[] toppingTokens = scan.nextLine().split("\\s+");
                    if(toppingTokens[0].equals("END")){
                        break;
                    }
                    try {
                        Topping topping = new Topping(toppingTokens[1], Integer.parseInt(toppingTokens[2]));
                        pizza.addTopping(topping);
                    }catch (IllegalArgumentException iea){
                        System.out.println(iea.getMessage());
                        passedAllTest = false;
                    }

                }

            }catch (IllegalArgumentException iea){
                System.out.println(iea.getMessage());
                passedAllTest = false;
            }
        }
        catch (IllegalArgumentException iae){
            System.out.println(iae.getMessage());
            passedAllTest = false;
        }
        if(passedAllTest){
            pizza.calculateCalories();
        }
    }
}
