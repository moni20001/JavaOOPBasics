package WildFarm;

public abstract class Felime extends Mammal
{
    public Felime(String name, Double weight, String animaltype, String livingRegion) {
        super(name, weight, animaltype, livingRegion);
    }
}
