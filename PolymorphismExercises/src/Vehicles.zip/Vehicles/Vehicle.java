package Vehicles;

import java.text.DecimalFormat;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumation;
    private double distanceTraveled;

    public Vehicle(double fuelQuantity, double fuelConsumation) {
        this.setDistanceTraveled(0);
        this.setFuelConsumation(fuelConsumation);
        this.setFuelQuantity(fuelQuantity);
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    private void setFuelConsumation(double fuelConsumation) {
        this.fuelConsumation = fuelConsumation;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    protected void setDistanceTraveled(double distanceTraveled) {
        this.distanceTraveled += distanceTraveled;
    }
    void refuel(double refuelQuantity) {
        this.fuelQuantity = (this.fuelQuantity + refuelQuantity);
    }
    @Override
    public String toString() {
        return String.format("%s: %.2f",
                this.getClass().getSimpleName(),
                this.fuelQuantity);
    }

    public double getFuelConsumation() {
        return fuelConsumation;
    }

    public abstract void drive(double distance);

}
