public class Person {
    private String firstName;
    private String lastName;
    private int age;

    Person(String a1 , String a2 , int age){
        this.firstName = a1;
        this.lastName = a2;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return this.firstName+ " "+this.lastName + " is " + this.age +" years old.";
    }
}
