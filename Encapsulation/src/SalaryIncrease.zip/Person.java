public class Person {
    private String firstName;
    private String lastName;
    private int age;
    private double salary;

    Person(String a1 , String a2 , int age,double salary){
        this.firstName = a1;
        this.lastName = a2;
        this.age = age;
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    public  void increaseSalary(Double bonus){
        if(this.age>30){
            this.salary += this.salary * bonus /100;
        }
        else{
            this.salary += this.salary * bonus /200;
        }
    }
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return this.firstName+ " "+this.lastName + " gets " + this.salary +" leva";
    }
}
