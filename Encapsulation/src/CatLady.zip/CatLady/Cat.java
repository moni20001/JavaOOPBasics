package CatLady;

public class Cat {

    private String name;
    public String type;

    public Cat(String name) {
        this.name = name;
    }




    public String getName() {
        return name;
    }
}
