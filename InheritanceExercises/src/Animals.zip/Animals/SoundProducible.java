package Animals;

public interface SoundProducible {
    String produceSound();
}
